import java.util.ArrayList;
import java.util.Arrays;
public class BasicJavaTest {
    public static void main(String[] args) {
        BasicJava a = new BasicJava();
        //1 
        // a.print255();

        //2
        //  a.printOdd();

        //3
        //  a.printSum(); 

        //4
        // int[] x = {1,3,5,7,9,13};
        // a.IterateArr(x);

        //5
        // int[] y = {-3,-5,-7}; 
        // a.findMax(y);

        //6
        // double[] x = {2, 10, 3};
        // a.getAvg(x);

        //7
        // a.arrOdd();

        //8
        // int[] testY = {1,3,5,7};
        // a.greaterY(testY, 3);

        //9
        // int[] testV = {1,5,10,-2};
        // a.squareValue(testV);

        //10
        // int[] testN = {1,5,10,-2};
        // a.eliNegative(testN);

        //11
        // int[] testA = {1,5,10,-2};
        // a.maxminAvg(testA);

        //12
        int[] testS = {1,5,10,7,-2};
        a.shifValue(testS);

    }
}
