public class FirstJava {
    public static void main(String[] args) {
        System.out.println("My name is Sunjuyuhwa Henderson");
        System.out.println("I am 37 years old");
        System.out.println("My hometown is Chuncheon, Gangwondo in South Korea");
    }
}