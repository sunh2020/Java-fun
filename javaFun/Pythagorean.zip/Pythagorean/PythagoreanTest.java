public class PythagoreanTest {
    public static void main(String[] args) {
        Pythagorean test = new Pythagorean();
        // System.out.println(); 
        test.calculateHypotenuse(6, 9);
    }
}  