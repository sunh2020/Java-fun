public class ListofExceptionsTest {
  public static void main(String[] args) {
      ListofExceptions e = new ListofExceptions();
      e.myList();
  }
}  